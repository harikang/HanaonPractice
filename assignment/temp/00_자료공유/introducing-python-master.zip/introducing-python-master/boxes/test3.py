import report

description = report.get_description()
print("Today's weather:", description)
