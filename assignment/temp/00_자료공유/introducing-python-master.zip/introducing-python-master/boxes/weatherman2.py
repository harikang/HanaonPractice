import report as wr
description = wr.get_description()
print("Today's weather:", description)
