a = 1
b = 2
c = 3
print(a)
print(b)
print(c)
