for countdown in 5, 4, 3, 2, 1, "hey!":
    print(countdown)
