def pp(*items):
    for item in items:
            print("==>", item)
            ptint("======>", type(item))
            import sys
            sys.exit()

def ppb(*items):
    for item in items:
            print("==>", item)
            ptint("======>", type(item))
            import sys
            sys.exit()