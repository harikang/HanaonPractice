import os
from helpers.debug import *
class Sec02_01:
    def Sec02_01_03(self):
        pp(a)
        a = int(a)
        pp(a)
        pp(dir("문자열"))
        #dir : 객체가 가지고 있는 속성 기능을 리스트 타입으로 리턴해준다.
        # IDE : 통합개발환경