from sec02.sec02_01 import Sec02_01

if __name__ == '__main__':
    Sec02_01.Sec02_01_01()
    Sec02_01.Sec02_01_02()
    Sec02_01.Sec02_01_03()  # type
