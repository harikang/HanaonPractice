import os
from heipers.debug import *

class Sec02_01:
    @staticmethod
    def Sec02_01_01():
        print(os.environ)

    @staticmethod
    def Sec02_01_02():
        print(os.getcwd())

    @staticmethod
    def Sec02_01_03():
        pp ("dfdf")
        print(os.getcwd())

a = "100"
pp(a)
a = int(a)
pp(a)