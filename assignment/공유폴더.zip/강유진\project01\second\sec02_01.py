import os
from helpers.debug import

if __name__ == "__main__":
    fs = First
    결과 = fs.처음만든함수1()
    print(결과)
    print("====>"fs.처음만든함수1().__doc__)

class Sec02_01:
    = 파이썬
    배터리인클루디드
    print(os.environ)
    @staticmethod
    def Sec02_01():
        print(os.environ)

    def Sec02_01_02():
        print(os.getowd())

    def Sec02_01_03():
        #내장함수
        type()
        pp("잘됨")
        print(os.getowd())
        print(type("sdfsdf"))
        #월시타입, 프리미티브타입스, 레퍼런스타입

    #하이픈 -v
    통용되는 규칙
    --풀네임 version
    -축약 v

    타입 컨버전

    int(a)




    class sec02_01:
        pp(a)
        a = int(a)
        pp(a)
        pp(dir("문자열"))
        #dir:객체가 가지고 있는 속성 기능을 리스트 타입으로 리턴해준다
        "문자열"