class Firstsection:
    def __init__(self):
        pass
    def 처음만든함수(self) -> object:
        """함수가 하는이를 적어주는거
        a: int
        b: int
        return object
        """