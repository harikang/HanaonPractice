import os
from helpers.debug import *

class Sec02_01:
    @staticmethod
    def Sec02_01_01():
        print(os.environ)

class Sec02_01:
    pp(a)

class Sec02_01:
    def Sec02_01_03(self):
        #str
        #원시타입은 타입캐스팅