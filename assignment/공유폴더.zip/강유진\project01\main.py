from second.sec02_01 import Sec02_01

if __name__ == '__main__':
    sec02_01 = Sec02_01()
    sec02_01.Sec02_01_02()

