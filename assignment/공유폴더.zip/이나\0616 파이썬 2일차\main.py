from exam import exam

if __name__ == '__main__':
    score = int(input("성적을 입력하세요: "))
    print(exam.성적처리(score))