과일들 = {"사과", "배"}

for 과일 in 과일들:
    print(f'과일이름은 {item} 입니다.')
    if print (f'{}째 과일은 {item}입니다.')

for i in range(0,;len{과일들}):
    print(f'과일이름은 {과일들{1}) 입니다.')
    if print(f'{}째 과일은 {item}입니다.')
