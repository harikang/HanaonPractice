def 성적처리(score):
    result = 'F'
    if score >= 90:
        result = 'A'
    elif score >= 80:
        result = 'B'
    elif score >= 70:
        result = 'C'
    elif score >= 60:
        result = 'D'
    return result






