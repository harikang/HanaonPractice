def 처음만든함수2():
    return "2장"