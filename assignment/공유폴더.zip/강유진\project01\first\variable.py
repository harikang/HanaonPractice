class First:
    def __init__(self):
        pass
    def 처음만든함수1() -> object:
        """함수가 하는 일을 적어주는거"""

        return "1장"

def asdf(a: int):
    """
    sdfsdfsdf: None
    """
    pass

