def 두번째로만든함수():
    return"2장"

