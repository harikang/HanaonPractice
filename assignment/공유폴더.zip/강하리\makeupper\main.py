
from src import *

if __name__ == '__main__':
    r = reader('D:\workspace_hanabank\Chapter07\makeupper\src.txt')
    writer('D:\workspace_hanabank\Chapter07\makeupper\dest.txt', r)