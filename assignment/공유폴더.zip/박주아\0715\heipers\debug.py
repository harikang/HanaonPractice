def pp(itmes):
    for item in items:
        print(type(item))

def ppb(itmes):
    for item in items:
        print(type(item))
    import sys
    sys.exit()