from first.variable import First
from second.ifffff import 두번째로만든함수

if __name__ == "__main__":
    fs = First()
    결과 = fs.처음만든함수()
    print(결과)