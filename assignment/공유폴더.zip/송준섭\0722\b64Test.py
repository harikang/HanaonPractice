import b64

b64.str_to_base64('ham')
