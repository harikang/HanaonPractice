# 함수 정의
def func(message):
    print(message)


# 정의한 함수 호출
func('안녕하세요')
