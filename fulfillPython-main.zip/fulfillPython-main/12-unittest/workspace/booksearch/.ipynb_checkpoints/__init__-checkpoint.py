from .core import Book, get_books
__all__ = ['Book', 'get_books']